//
//  ViewController.swift
//  第一章基础语法简介
//
//  Created by 周希财 on 2017/9/19.
//  Copyright © 2017年 VIC. All rights reserved.


// Swift4.0编程语言学习
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //第一节 Swift 基础类型体系
        //Swift编程语言 只包含4种类型 即1：枚举（enum）2：结构体（struct）3：类（class）4：函数类型（functiontypes）
        //其中枚举和结构体属于值类型（ValueTypes），类和函数属于引用类型（referencetypes）
        //除此之外，还有一个队数据组织的容器--元组（tiple）
        
        //Swift是一门安全性语言。Swift编程语言可以给任何一个可选的（Optional）类型置空 然而，java、OC、C++等，只能给指针或者引用类型的对象置空，而不能队值得对象置空
        
        
        //第二节 变量对象
        //变量对象定义：在Swift中，我们通过关键字var声明一个对象称为变量对象,简称变量（variable）。
        //变量的使用：1.如果一个变量的对象是一个结构体或者是枚举（即类型变量），那么该对象的自身值允许改变，切其成员变量也能被修改。
                  //2.如果一个变量的对象是一个类类型，那么该对象引用可以修改，且该对象的实例中的所有成员变量也能被修改。
        
        //eg:
        var a = 10 //声明一个变量a 初始值为10
        a = 100    //a被修改
        
        //声明一个简单的结构体
        struct S{
            var s = 0   //声明一个成员变量s
        }
        
        var b = S() //b声明一个S结构体的变量
        
        b.s = 10    //将b的成员变量s修改成10
        
        b = S()     //这里b又被赋给了一个新的S结构体变量
        
        
        
        //第三节 常量对象
        //常量对象定义：在Swift中，我们通过关键字let声明的对象为常量对象，简称常量（constant）
        //常量对象的使用：1.如果一个常量对象对的类型为一个枚举或结构体（即类型变量）类型，那么，该对象的值及其成员变量的值都不允许被修改。
                     //2.如果一个常量对象的类型是一个类类型，那么该对象引用不能被改变，但是他所引用的对象实例中的成员变量允许被修改。
        //eg:
        let leta = 100  //声明一个整数对象为一个常量
        //下面这行代码会出错
        // leta = 10
        
        //声明一个简单的结构体
        struct LetS{
            var s = 10
        }
        
        let letB = LetS()
        
        //下面这行代码会出错
        //letB = LetS();
        //下面这行代码会出错
        //letB.s = 100

        //定义一个简单的类
        class c{
            var c = 0
        }
        
        let letC = c();
        
        letC.c = 10    //这句代码是没有问题的 这里对c所引用的对象的成员进行修改时允许的
        
        //下面这行代码会出错
        //letC = c();    //如果一个常量对象的类型是一个类类型，那么该对象引用不能被改变。
        
        //另外，Swift中除了一般整数、浮点数、字符串、数组字典等结构体类型的字面量属于常量之外，结构体与枚举类型直接构造出的对象也属于常量，我们不能直接对由这些类型构造的对象实例做实例属性的修改
        //eg:
        struct MyObject{
        
            var a = 0, b = 1
            
        }
        
        var obj = MyObject()
        
        obj.a += obj.b   //这个语句没有问题，因为obj是一个变量
        //下面这行代码会出错
        //MyObject().a += 10    //直接用结构体类型构造出的对象是不可修改的
        
        
        //而对于类类型直接创建的对象实例则可对其实例属性进行修改
        //eg:
        class Test{
        
            var a = 0, b = 1
            
        }
        
        Test().a += Test().b
        
        
        //Swift中允许一个常量先被声明再被初始化，但是只能初始化一次。如果这个常量被初始化之后，再给其赋值，编译器就会报错。
        //eg:
        let IntA : Int

        let IntB = 10, IntC = 20
        
        IntA = IntB + IntC   //这里为IntA初始化，没有问题
        
        
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

